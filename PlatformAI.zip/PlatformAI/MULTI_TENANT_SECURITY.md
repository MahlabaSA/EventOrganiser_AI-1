# Multi-Tenant Security Architecture

## Phase 1 Implementation Status

### ✅ Completed Database Schema
All tables now include explicit `organizationId` foreign keys:
- **Root:** organizations
- **Tenant-scoped:** users, projects, events, tasks, risks, speakers, attendees, sponsors, sessions, venueLayouts, analytics

### 🔒 Security Architecture

#### Database-Level Isolation (✅ IMPLEMENTED - Phase 1)

**PostgreSQL Triggers** enforce tenant isolation at the database level:

1. **Foreign Key Foundation**
   - All tables have `organizationId NOT NULL` foreign keys
   - Cascading deletes ensure complete tenant data removal
   - Parent-child relationships enforced via FK constraints

2. **Trigger-Based Validation** (see `server/migrations/multi-tenant-triggers.sql`)
   - **User Assignment Triggers**: Prevent cross-tenant user assignments on projects, tasks, risks, events, venue_layouts
   - **Parent-Child Organization Triggers**: Enforce organizationId matching between parent and child records
   - **Automatic Enforcement**: Runs on INSERT and UPDATE operations

3. **Installation & Deployment**
   ```bash
   # Apply triggers to new database
   npm run db:setup        # Runs schema push + triggers
   
   # Or manually
   npm run db:push -- --force
   npx tsx server/apply-triggers.ts
   ```

4. **Automated Testing**
   ```bash
   # Verify triggers are working
   npx tsx server/test-multi-tenant-isolation.ts
   ```

#### Application-Level Validation (Defense in Depth)
While database triggers provide primary enforcement, API layer SHOULD also validate:

##### Critical Validation Rules
1. **User Assignment Validation**
   - Before assigning any user (assignedTo, createdBy, projectManager, owner) to a record, verify:
     ```typescript
     const user = await db.select().from(users).where(eq(users.id, userId));
     if (user.organizationId !== record.organizationId) {
       throw new Error("Cross-tenant user assignment forbidden");
     }
     ```

2. **Parent-Child Organization Match**
   - Events → Projects: Verify event.organizationId === project.organizationId
   - Tasks → Projects: Verify task.organizationId === project.organizationId  
   - Risks → Projects: Verify risk.organizationId === project.organizationId
   - Sessions → Events: Verify session.organizationId === event.organizationId
   - All child entities → parent entities must share same organizationId

3. **Query Scoping**
   - ALL database queries MUST include organizationId filter:
     ```typescript
     // CORRECT
     db.select().from(events).where(
       and(
         eq(events.organizationId, currentOrg.id),
         eq(events.id, eventId)
       )
     );

     // INCORRECT - allows cross-tenant access
     db.select().from(events).where(eq(events.id, eventId));
     ```

### ✅ Security Verification

#### Automated Tests
Run the test suite to verify isolation:
```bash
npx tsx server/test-multi-tenant-isolation.ts
```

**Test Coverage:**
- ✅ Blocks cross-tenant project manager assignment
- ✅ Blocks cross-tenant task assignment
- ✅ Blocks cross-tenant risk owner assignment  
- ✅ Blocks parent-child organizationId mismatch
- ✅ Allows valid same-organization operations

#### Manual Verification
```sql
-- Attempt cross-tenant assignment (should fail)
INSERT INTO projects (organization_id, name, status, budget, project_manager)
SELECT 
  'org2-id', 
  'Test', 
  'planning', 
  10000, 
  (SELECT id FROM users WHERE organization_id = 'org1-id' LIMIT 1)
;
-- Expected: ERROR: Cannot assign project manager from different organization
```

### 📋 API Implementation Checklist

Every API endpoint MUST:
- [ ] Extract organizationId from authenticated user context
- [ ] Include organizationId in WHERE clause for all SELECT queries
- [ ] Validate organizationId matches for all INSERT operations
- [ ] Verify parent record organizationId before creating child records
- [ ] Check user organizationId before assignment operations
- [ ] Return 403 Forbidden for cross-tenant access attempts

### 🛡️ Security Testing Requirements

Before Phase 1 completion, verify:
1. **Isolation Test:** Create 2+ organizations and verify complete data isolation
2. **Assignment Test:** Attempt to assign user from Org A to task in Org B (should fail)
3. **Query Test:** Attempt to access event from different organization (should return 404/403)
4. **Cascade Test:** Delete organization and verify all tenant data removed

### 📊 ISO Compliance Mapping

- **ISO 27001 (Information Security):** Multi-tenant isolation prevents unauthorized data access
- **ISO 9001 (Quality Management):** Documented validation procedures ensure consistency
- **ISO 20121 (Event Sustainability):** Tenant-scoped data enables per-organization sustainability tracking
- **ISO 31000 (Risk Management):** Organization-specific risk registers with proper isolation

### ⚠️ Critical Warning

**DO NOT deploy to production without implementing ALL application-level validations.**

The database schema provides foundational structure but does NOT fully prevent cross-tenant data exposure for user assignments. API validation is MANDATORY.

---

**Last Updated:** Phase 1 Foundation - November 2025
**Next Review:** Before Phase 2 (Advanced AI Features)
