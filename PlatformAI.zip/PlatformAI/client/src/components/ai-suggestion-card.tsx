import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, Check, X } from "lucide-react";
import { useState } from "react";

interface AISuggestionCardProps {
  title: string;
  description: string;
  confidence?: number;
}

export function AISuggestionCard({ title, description, confidence }: AISuggestionCardProps) {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-start gap-2 flex-1">
            <div className="p-1.5 rounded-md bg-primary/10">
              <Sparkles className="h-4 w-4 text-primary" />
            </div>
            <div className="flex-1">
              <CardTitle className="text-sm font-medium">{title}</CardTitle>
              {confidence !== undefined && (
                <span className="text-xs text-muted-foreground">
                  {confidence}% confidence
                </span>
              )}
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground">{description}</p>
        <div className="flex gap-2">
          <Button 
            size="sm" 
            variant="default" 
            className="flex-1"
            onClick={() => console.log('Accepted suggestion:', title)}
            data-testid="button-accept-suggestion"
          >
            <Check className="h-3 w-3 mr-1" />
            Accept
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => setDismissed(true)}
            data-testid="button-dismiss-suggestion"
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
