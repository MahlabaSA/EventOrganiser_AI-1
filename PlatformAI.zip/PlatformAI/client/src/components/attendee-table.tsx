import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MoreHorizontal } from "lucide-react";

interface Attendee {
  id: string;
  name: string;
  email: string;
  company: string;
  status: "registered" | "checked-in" | "no-show";
  ticketType: string;
}

interface AttendeeTableProps {
  attendees: Attendee[];
}

const statusColors = {
  registered: "bg-blue-500/10 text-blue-700 dark:text-blue-400",
  "checked-in": "bg-green-500/10 text-green-700 dark:text-green-400",
  "no-show": "bg-red-500/10 text-red-700 dark:text-red-400",
};

export function AttendeeTable({ attendees }: AttendeeTableProps) {
  return (
    <div className="border rounded-md">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Attendee</TableHead>
            <TableHead>Company</TableHead>
            <TableHead>Ticket Type</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {attendees.map((attendee) => (
            <TableRow key={attendee.id} data-testid={`row-attendee-${attendee.id}`}>
              <TableCell>
                <div className="flex items-center gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="text-xs">
                      {attendee.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col">
                    <span className="font-medium text-sm">{attendee.name}</span>
                    <span className="text-xs text-muted-foreground">{attendee.email}</span>
                  </div>
                </div>
              </TableCell>
              <TableCell className="text-sm">{attendee.company}</TableCell>
              <TableCell className="text-sm">{attendee.ticketType}</TableCell>
              <TableCell>
                <Badge className={statusColors[attendee.status]}>
                  {attendee.status}
                </Badge>
              </TableCell>
              <TableCell>
                <Button 
                  variant="ghost" 
                  size="icon"
                  data-testid={`button-actions-${attendee.id}`}
                >
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
