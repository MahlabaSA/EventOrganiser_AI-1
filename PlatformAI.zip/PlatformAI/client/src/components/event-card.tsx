import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Users, DollarSign } from "lucide-react";
import { format } from "date-fns";

interface EventCardProps {
  id: string;
  title: string;
  startDate: Date;
  endDate: Date;
  venue: string;
  attendees: number;
  budget: number;
  status: "planning" | "active" | "completed" | "cancelled";
  imageUrl?: string;
}

const statusColors = {
  planning: "bg-blue-500/10 text-blue-700 dark:text-blue-400",
  active: "bg-green-500/10 text-green-700 dark:text-green-400",
  completed: "bg-gray-500/10 text-gray-700 dark:text-gray-400",
  cancelled: "bg-red-500/10 text-red-700 dark:text-red-400",
};

export function EventCard({
  id,
  title,
  startDate,
  endDate,
  venue,
  attendees,
  budget,
  status,
  imageUrl,
}: EventCardProps) {
  return (
    <Card className="overflow-hidden hover-elevate" data-testid={`card-event-${id}`}>
      {imageUrl && (
        <div className="aspect-video bg-muted relative overflow-hidden">
          <img src={imageUrl} alt={title} className="w-full h-full object-cover" />
        </div>
      )}
      <CardHeader className="space-y-2">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold text-lg line-clamp-1">{title}</h3>
          <Badge className={statusColors[status]} data-testid={`badge-status-${status}`}>
            {status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="h-4 w-4" />
          <span>{format(startDate, "MMM d")} - {format(endDate, "MMM d, yyyy")}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4" />
          <span className="line-clamp-1">{venue}</span>
        </div>
        <div className="grid grid-cols-2 gap-3 pt-2 border-t">
          <div className="flex items-center gap-2 text-sm">
            <Users className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{attendees.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <DollarSign className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">${(budget / 1000).toFixed(0)}k</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex gap-2">
        <Button variant="default" className="flex-1" data-testid={`button-view-${id}`}>
          View Details
        </Button>
        <Button variant="outline" data-testid={`button-edit-${id}`}>
          Edit
        </Button>
      </CardFooter>
    </Card>
  );
}
