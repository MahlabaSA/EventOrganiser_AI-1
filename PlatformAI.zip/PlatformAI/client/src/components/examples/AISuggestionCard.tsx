import { AISuggestionCard } from '../ai-suggestion-card';

export default function AISuggestionCardExample() {
  return (
    <AISuggestionCard
      title="Optimize Session Timing"
      description="Based on attendee behavior patterns, consider moving the keynote to 10:00 AM for 23% higher engagement."
      confidence={92}
    />
  );
}
