import { AnalyticsChart } from '../analytics-chart';

const data = [
  { name: "Jan", value: 1200 },
  { name: "Feb", value: 1800 },
  { name: "Mar", value: 2200 },
  { name: "Apr", value: 2800 },
  { name: "May", value: 3500 },
];

export default function AnalyticsChartExample() {
  return (
    <AnalyticsChart
      title="Attendance Forecast"
      description="AI-predicted attendance trends"
      data={data}
    />
  );
}
