import { AttendeeTable } from '../attendee-table';

const mockAttendees = [
  {
    id: "1",
    name: "Sarah Johnson",
    email: "sarah.johnson@techcorp.com",
    company: "TechCorp Global",
    status: "checked-in" as const,
    ticketType: "VIP Pass",
  },
  {
    id: "2",
    name: "Michael Chen",
    email: "m.chen@innovate.io",
    company: "Innovate Solutions",
    status: "registered" as const,
    ticketType: "Standard",
  },
];

export default function AttendeeTableExample() {
  return <AttendeeTable attendees={mockAttendees} />;
}
