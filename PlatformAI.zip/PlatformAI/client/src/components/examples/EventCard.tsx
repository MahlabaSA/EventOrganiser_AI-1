import { EventCard } from '../event-card';

export default function EventCardExample() {
  return (
    <EventCard
      id="1"
      title="Global Tech Summit 2025"
      startDate={new Date("2025-03-15")}
      endDate={new Date("2025-03-17")}
      venue="Cape Town Convention Centre, South Africa"
      attendees={2500}
      budget={450000}
      status="planning"
    />
  );
}
