import { MetricCard } from '../metric-card';
import { Calendar } from 'lucide-react';

export default function MetricCardExample() {
  return <MetricCard title="Total Events" value={12} change={8.2} icon={Calendar} />;
}
