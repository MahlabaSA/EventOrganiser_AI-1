import { RealTimeDashboard } from '../real-time-dashboard';

const mockMetrics = [
  { label: "Check-ins", value: 1847, status: "normal" as const },
  { label: "Active Sessions", value: 12, status: "normal" as const },
  { label: "Engagement", value: "89%", status: "normal" as const },
  { label: "App Users", value: 2103, status: "warning" as const },
];

export default function RealTimeDashboardExample() {
  return <RealTimeDashboard metrics={mockMetrics} />;
}
