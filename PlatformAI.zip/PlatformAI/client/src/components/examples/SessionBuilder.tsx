import { SessionBuilder } from '../session-builder';

const mockSessions = [
  {
    id: "1",
    title: "Opening Keynote: The Future of AI",
    speaker: "Dr. Sarah Chen",
    startTime: "09:00",
    duration: 60,
    capacity: 500,
    track: "Main Stage",
  },
  {
    id: "2",
    title: "Workshop: Building Scalable Systems",
    speaker: "Michael Rodriguez",
    startTime: "11:00",
    duration: 90,
    capacity: 50,
    track: "Technical",
  },
];

export default function SessionBuilderExample() {
  return <SessionBuilder sessions={mockSessions} />;
}
