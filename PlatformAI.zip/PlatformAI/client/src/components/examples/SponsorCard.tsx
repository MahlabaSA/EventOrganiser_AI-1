import { SponsorCard } from '../sponsor-card';

export default function SponsorCardExample() {
  return (
    <SponsorCard
      id="1"
      name="TechCorp International"
      tier="platinum"
      package="Platinum Plus"
      amount={150000}
      roi={340}
      leads={248}
    />
  );
}
