import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Users, MessageSquare, AlertCircle } from "lucide-react";

interface RealTimeMetric {
  label: string;
  value: number | string;
  status?: "normal" | "warning" | "critical";
}

interface RealTimeDashboardProps {
  metrics: RealTimeMetric[];
}

const statusColors = {
  normal: "bg-green-500/10 text-green-700 dark:text-green-400",
  warning: "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400",
  critical: "bg-red-500/10 text-red-700 dark:text-red-400",
};

export function RealTimeDashboard({ metrics }: RealTimeDashboardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
        <div className="flex items-center gap-2">
          <Activity className="h-5 w-5 text-primary animate-pulse" />
          <CardTitle className="text-lg">Live Event Monitor</CardTitle>
        </div>
        <Badge className="bg-green-500/10 text-green-700 dark:text-green-400">
          Active
        </Badge>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {metrics.map((metric, index) => (
            <div 
              key={index} 
              className="space-y-1"
              data-testid={`metric-${metric.label.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">{metric.label}</span>
                {metric.status && metric.status !== "normal" && (
                  <AlertCircle className="h-3 w-3 text-yellow-600" />
                )}
              </div>
              <div className="text-2xl font-bold">{metric.value}</div>
              {metric.status && (
                <Badge className={statusColors[metric.status]} variant="outline">
                  {metric.status}
                </Badge>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
