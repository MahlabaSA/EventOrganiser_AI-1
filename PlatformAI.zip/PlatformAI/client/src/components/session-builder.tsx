import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Users, Plus, GripVertical } from "lucide-react";
import { useState } from "react";

interface Session {
  id: string;
  title: string;
  speaker: string;
  startTime: string;
  duration: number;
  capacity: number;
  track?: string;
}

interface SessionBuilderProps {
  sessions: Session[];
}

export function SessionBuilder({ sessions: initialSessions }: SessionBuilderProps) {
  const [sessions] = useState(initialSessions);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
        <CardTitle className="text-lg">Event Agenda</CardTitle>
        <Button size="sm" data-testid="button-add-session">
          <Plus className="h-4 w-4 mr-1" />
          Add Session
        </Button>
      </CardHeader>
      <CardContent className="space-y-2">
        {sessions.map((session) => (
          <div
            key={session.id}
            className="flex items-center gap-3 p-4 border rounded-md hover-elevate"
            data-testid={`session-${session.id}`}
          >
            <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
            <div className="flex-1 space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h4 className="font-medium">{session.title}</h4>
                {session.track && (
                  <Badge variant="outline" className="text-xs">
                    {session.track}
                  </Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground">{session.speaker}</p>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  <span>{session.startTime} ({session.duration}min)</span>
                </div>
                <div className="flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  <span>{session.capacity} seats</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
