import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Building2, DollarSign, TrendingUp } from "lucide-react";

interface SponsorCardProps {
  id: string;
  name: string;
  tier: "platinum" | "gold" | "silver" | "bronze";
  package: string;
  amount: number;
  roi?: number;
  leads?: number;
}

const tierColors = {
  platinum: "bg-slate-500/10 text-slate-700 dark:text-slate-300",
  gold: "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400",
  silver: "bg-gray-400/10 text-gray-700 dark:text-gray-400",
  bronze: "bg-orange-600/10 text-orange-700 dark:text-orange-400",
};

export function SponsorCard({ id, name, tier, package: pkg, amount, roi, leads }: SponsorCardProps) {
  return (
    <Card data-testid={`card-sponsor-${id}`}>
      <CardHeader>
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-3 flex-1">
            <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center">
              <Building2 className="h-5 w-5 text-muted-foreground" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold">{name}</h3>
              <p className="text-sm text-muted-foreground">{pkg}</p>
            </div>
          </div>
          <Badge className={tierColors[tier]}>{tier}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <DollarSign className="h-4 w-4" />
            <span>Investment</span>
          </div>
          <span className="font-semibold">${amount.toLocaleString()}</span>
        </div>
        {roi !== undefined && (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <TrendingUp className="h-4 w-4" />
              <span>ROI</span>
            </div>
            <span className="font-semibold text-green-600">{roi}%</span>
          </div>
        )}
        {leads !== undefined && (
          <div className="flex items-center justify-between pt-3 border-t">
            <span className="text-sm text-muted-foreground">Leads Generated</span>
            <span className="font-semibold">{leads}</span>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button variant="outline" className="w-full" data-testid={`button-view-sponsor-${id}`}>
          View Dashboard
        </Button>
      </CardFooter>
    </Card>
  );
}
