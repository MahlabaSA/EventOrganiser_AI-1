import { useQuery } from "@tanstack/react-query";
import type { Analytics } from "@shared/schema";

export function useAnalytics(eventId: string | undefined) {
  return useQuery<Analytics[]>({
    queryKey: ["/api/events", eventId, "analytics"],
    enabled: !!eventId,
  });
}

export function useDashboardStats() {
  return useQuery<{
    totalEvents: number;
    activeEvents: number;
    totalAttendees: number;
    totalRevenue: number;
    engagementRate: number;
  }>({
    queryKey: ["/api/dashboard/stats"],
  });
}
