import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Attendee, InsertAttendee } from "@shared/schema";

export function useAttendees(eventId: string | undefined) {
  return useQuery<Attendee[]>({
    queryKey: ["/api/events", eventId, "attendees"],
    enabled: !!eventId,
  });
}

export function useCreateAttendee() {
  return useMutation({
    mutationFn: async (data: InsertAttendee) => {
      const res = await apiRequest("POST", "/api/attendees", data);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/events", variables.eventId, "attendees"] 
      });
    },
  });
}

export function useCheckInAttendee() {
  return useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("PATCH", `/api/attendees/${id}/check-in`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
    },
  });
}
