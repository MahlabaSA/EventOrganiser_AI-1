import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Session, InsertSession } from "@shared/schema";

export function useSessions(eventId: string | undefined) {
  return useQuery<Session[]>({
    queryKey: ["/api/events", eventId, "sessions"],
    enabled: !!eventId,
  });
}

export function useCreateSession() {
  return useMutation({
    mutationFn: async (data: InsertSession) => {
      const res = await apiRequest("POST", "/api/sessions", data);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/events", variables.eventId, "sessions"] 
      });
    },
  });
}

export function useUpdateSession(id: string) {
  return useMutation({
    mutationFn: async (data: Partial<InsertSession>) => {
      const res = await apiRequest("PATCH", `/api/sessions/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
    },
  });
}
