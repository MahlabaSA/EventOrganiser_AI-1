import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Sponsor, InsertSponsor } from "@shared/schema";

export function useSponsors(eventId: string | undefined) {
  return useQuery<Sponsor[]>({
    queryKey: ["/api/events", eventId, "sponsors"],
    enabled: !!eventId,
  });
}

export function useCreateSponsor() {
  return useMutation({
    mutationFn: async (data: InsertSponsor) => {
      const res = await apiRequest("POST", "/api/sponsors", data);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/events", variables.eventId, "sponsors"] 
      });
    },
  });
}

export function useUpdateSponsor(id: string) {
  return useMutation({
    mutationFn: async (data: Partial<InsertSponsor>) => {
      const res = await apiRequest("PATCH", `/api/sponsors/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
    },
  });
}
