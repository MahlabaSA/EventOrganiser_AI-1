import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Send, FileText, Calendar, Users } from "lucide-react";
import { useState } from "react";

// TODO: Remove mock data
const aiCapabilities = [
  {
    icon: FileText,
    title: "Generate Content",
    description: "Create event descriptions, session titles, and marketing copy",
  },
  {
    icon: Calendar,
    title: "Optimize Schedule",
    description: "AI-powered agenda building with conflict detection",
  },
  {
    icon: Users,
    title: "Attendee Matching",
    description: "Smart networking recommendations and matchmaking",
  },
];

const samplePrompts = [
  "Generate a compelling event description for a tech summit",
  "Suggest optimal session times for maximum attendance",
  "Create personalized attendee recommendations",
  "Analyze sponsor ROI and suggest improvements",
];

export default function AIAssistant() {
  const [prompt, setPrompt] = useState("");
  const [messages, setMessages] = useState<Array<{ role: string; content: string }>>([
    {
      role: "assistant",
      content:
        "Hello! I'm your AI event planning assistant. I can help you generate content, optimize schedules, predict attendance, and much more. How can I assist you today?",
    },
  ]);

  const handleSend = () => {
    if (!prompt.trim()) return;

    setMessages([
      ...messages,
      { role: "user", content: prompt },
      {
        role: "assistant",
        content:
          "This is a demo response. In the full application, I would use OpenAI to generate intelligent responses based on your event data and requirements.",
      },
    ]);
    setPrompt("");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-semibold font-serif flex items-center gap-2">
            <Sparkles className="h-8 w-8 text-primary" />
            AI Assistant
          </h1>
          <p className="text-muted-foreground mt-1">
            Your intelligent event planning co-pilot
          </p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {aiCapabilities.map((capability, index) => (
          <Card key={index}>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-md bg-primary/10">
                  <capability.icon className="h-5 w-5 text-primary" />
                </div>
                <CardTitle className="text-base">{capability.title}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{capability.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card className="h-[600px] flex flex-col">
            <CardHeader className="border-b">
              <CardTitle className="text-lg">Chat with AI</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      message.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted"
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                  </div>
                </div>
              ))}
            </CardContent>
            <div className="p-4 border-t">
              <div className="flex gap-2">
                <Textarea
                  placeholder="Ask me anything about your events..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  className="min-h-[60px]"
                  data-testid="input-ai-prompt"
                />
                <Button
                  onClick={handleSend}
                  disabled={!prompt.trim()}
                  data-testid="button-send-prompt"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Sample Prompts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {samplePrompts.map((sample, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="w-full justify-start text-left h-auto py-3 px-3"
                  onClick={() => setPrompt(sample)}
                  data-testid={`button-sample-prompt-${index}`}
                >
                  <span className="text-sm line-clamp-2">{sample}</span>
                </Button>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">AI Capabilities</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Badge variant="outline" className="w-full justify-start">
                Content Generation
              </Badge>
              <Badge variant="outline" className="w-full justify-start">
                Predictive Analytics
              </Badge>
              <Badge variant="outline" className="w-full justify-start">
                Schedule Optimization
              </Badge>
              <Badge variant="outline" className="w-full justify-start">
                Attendee Matching
              </Badge>
              <Badge variant="outline" className="w-full justify-start">
                ROI Forecasting
              </Badge>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
