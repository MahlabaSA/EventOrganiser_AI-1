import { AnalyticsChart } from "@/components/analytics-chart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Calendar } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

// TODO: Remove mock data
const attendanceData = [
  { name: "Jan", value: 1200 },
  { name: "Feb", value: 1800 },
  { name: "Mar", value: 2200 },
  { name: "Apr", value: 2800 },
  { name: "May", value: 3500 },
  { name: "Jun", value: 4200 },
];

const engagementData = [
  { name: "Mon", value: 65 },
  { name: "Tue", value: 72 },
  { name: "Wed", value: 85 },
  { name: "Thu", value: 78 },
  { name: "Fri", value: 90 },
];

const sessionData = [
  { name: "Keynote", value: 850 },
  { name: "Workshop A", value: 320 },
  { name: "Workshop B", value: 280 },
  { name: "Panel", value: 450 },
  { name: "Networking", value: 620 },
];

export default function Analytics() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-semibold font-serif">Analytics</h1>
          <p className="text-muted-foreground mt-1">
            AI-powered insights and predictive analytics
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" data-testid="button-date-range">
            <Calendar className="h-4 w-4 mr-2" />
            Last 6 Months
          </Button>
          <Button variant="outline" data-testid="button-export-report">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <AnalyticsChart
          title="Attendance Forecast"
          description="AI-predicted attendance trends"
          data={attendanceData}
        />
        <AnalyticsChart
          title="Engagement Rate"
          description="Daily attendee engagement percentage"
          data={engagementData}
          color="hsl(var(--chart-2))"
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Session Attendance</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={sessionData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis
                dataKey="name"
                className="text-xs"
                tick={{ fill: "hsl(var(--muted-foreground))" }}
              />
              <YAxis
                className="text-xs"
                tick={{ fill: "hsl(var(--muted-foreground))" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--popover))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "6px",
                }}
              />
              <Bar dataKey="value" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Revenue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">$1.2M</div>
            <p className="text-xs text-green-600 mt-1">+18.7% from last period</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Avg. Ticket Price
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">$485</div>
            <p className="text-xs text-green-600 mt-1">+12.3% from last period</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Conversion Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">24.5%</div>
            <p className="text-xs text-green-600 mt-1">+5.2% from last period</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
