import { AttendeeTable } from "@/components/attendee-table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Search, Download, Upload } from "lucide-react";
import { useState } from "react";

// TODO: Remove mock data
const mockAttendees = [
  {
    id: "1",
    name: "Sarah Johnson",
    email: "sarah.johnson@techcorp.com",
    company: "TechCorp Global",
    status: "checked-in" as const,
    ticketType: "VIP Pass",
  },
  {
    id: "2",
    name: "Michael Chen",
    email: "m.chen@innovate.io",
    company: "Innovate Solutions",
    status: "registered" as const,
    ticketType: "Standard",
  },
  {
    id: "3",
    name: "Emily Rodriguez",
    email: "emily.r@futuretech.com",
    company: "FutureTech Inc",
    status: "checked-in" as const,
    ticketType: "Premium",
  },
  {
    id: "4",
    name: "David Park",
    email: "d.park@startup.co",
    company: "StartupCo",
    status: "registered" as const,
    ticketType: "Standard",
  },
  {
    id: "5",
    name: "Lisa Thompson",
    email: "lisa@enterprise.com",
    company: "Enterprise Solutions",
    status: "no-show" as const,
    ticketType: "VIP Pass",
  },
];

export default function Attendees() {
  const [searchQuery, setSearchQuery] = useState("");

  const stats = {
    total: mockAttendees.length,
    checkedIn: mockAttendees.filter((a) => a.status === "checked-in").length,
    registered: mockAttendees.filter((a) => a.status === "registered").length,
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-semibold font-serif">Attendees</h1>
          <p className="text-muted-foreground mt-1">
            Manage event registrations and check-ins
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" data-testid="button-import">
            <Upload className="h-4 w-4 mr-2" />
            Import
          </Button>
          <Button variant="outline" data-testid="button-export">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button data-testid="button-add-attendee">
            <Plus className="h-4 w-4 mr-2" />
            Add Attendee
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Registered
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Checked In
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{stats.checkedIn}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Pending Check-in
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{stats.registered}</div>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search attendees..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search-attendees"
          />
        </div>
      </div>

      <AttendeeTable attendees={mockAttendees} />
    </div>
  );
}
