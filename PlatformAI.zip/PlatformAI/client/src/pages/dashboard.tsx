import { MetricCard } from "@/components/metric-card";
import { EventCard } from "@/components/event-card";
import { AISuggestionCard } from "@/components/ai-suggestion-card";
import { AnalyticsChart } from "@/components/analytics-chart";
import { Calendar, Users, DollarSign, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useEvents } from "@/hooks/use-events";
import { Skeleton } from "@/components/ui/skeleton";

const mockChartData = [
  { name: "Jan", value: 1200 },
  { name: "Feb", value: 1800 },
  { name: "Mar", value: 2200 },
  { name: "Apr", value: 2800 },
  { name: "May", value: 3500 },
  { name: "Jun", value: 4200 },
];

export default function Dashboard() {
  const { data: events, isLoading } = useEvents();
  
  const upcomingEvents = events?.slice(0, 3) || [];
  const totalEvents = events?.length || 0;
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-semibold font-serif">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Welcome back! Here's your event overview
          </p>
        </div>
        <Button data-testid="button-create-event">
          <Plus className="h-4 w-4 mr-2" />
          Create Event
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Total Events"
          value={totalEvents}
          change={8.2}
          icon={Calendar}
        />
        <MetricCard
          title="Total Attendees"
          value="24.5K"
          change={12.5}
          icon={Users}
        />
        <MetricCard
          title="Revenue"
          value="$1.2M"
          change={18.7}
          icon={DollarSign}
        />
        <MetricCard
          title="Engagement Rate"
          value="87%"
          change={5.3}
          icon={TrendingUp}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <AnalyticsChart
            title="Attendance Forecast"
            description="AI-predicted attendance trends for upcoming events"
            data={mockChartData}
          />
        </div>
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">AI Recommendations</h2>
          <AISuggestionCard
            title="Optimize Session Timing"
            description="Based on attendee behavior patterns, consider moving the keynote to 10:00 AM for 23% higher engagement."
            confidence={92}
          />
          <AISuggestionCard
            title="Sponsor Match Opportunity"
            description="TechCorp shows high alignment with your audience demographics. Predicted ROI: 340%"
            confidence={87}
          />
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-semibold">Upcoming Events</h2>
          <Button variant="outline" data-testid="button-view-all-events">
            View All
          </Button>
        </div>
        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-[400px]" />
            ))}
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {upcomingEvents.map((event) => (
              <EventCard 
                key={event.id} 
                id={event.id}
                title={event.title}
                startDate={new Date(event.startDate)}
                endDate={new Date(event.endDate)}
                venue={event.venue}
                attendees={0}
                budget={Number(event.budget)}
                status={event.status}
                imageUrl={event.imageUrl || undefined}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
