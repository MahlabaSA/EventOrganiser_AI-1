import { EventCard } from "@/components/event-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Search } from "lucide-react";
import { useState } from "react";
import { useEvents } from "@/hooks/use-events";
import { Skeleton } from "@/components/ui/skeleton";

export default function Events() {
  const [searchQuery, setSearchQuery] = useState("");
  const { data: events, isLoading } = useEvents();

  const filteredEvents = events?.filter(event => 
    event.title.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-semibold font-serif">Events</h1>
          <p className="text-muted-foreground mt-1">
            Manage all your events in one place
          </p>
        </div>
        <Button data-testid="button-create-event">
          <Plus className="h-4 w-4 mr-2" />
          Create Event
        </Button>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search events..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search-events"
          />
        </div>
      </div>

      <Tabs defaultValue="all" className="space-y-6">
        <TabsList>
          <TabsTrigger value="all" data-testid="tab-all">All Events</TabsTrigger>
          <TabsTrigger value="planning" data-testid="tab-planning">Planning</TabsTrigger>
          <TabsTrigger value="active" data-testid="tab-active">Active</TabsTrigger>
          <TabsTrigger value="completed" data-testid="tab-completed">Completed</TabsTrigger>
        </TabsList>

        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-[400px]" />
            ))}
          </div>
        ) : (
          <>
            <TabsContent value="all" className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredEvents.map((event) => (
                  <EventCard 
                    key={event.id} 
                    id={event.id}
                    title={event.title}
                    startDate={new Date(event.startDate)}
                    endDate={new Date(event.endDate)}
                    venue={event.venue}
                    attendees={0}
                    budget={Number(event.budget)}
                    status={event.status}
                    imageUrl={event.imageUrl || undefined}
                  />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="planning" className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredEvents
                  .filter((event) => event.status === "planning")
                  .map((event) => (
                    <EventCard 
                      key={event.id} 
                      id={event.id}
                      title={event.title}
                      startDate={new Date(event.startDate)}
                      endDate={new Date(event.endDate)}
                      venue={event.venue}
                      attendees={0}
                      budget={Number(event.budget)}
                      status={event.status}
                      imageUrl={event.imageUrl || undefined}
                    />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="active" className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredEvents
                  .filter((event) => event.status === "active")
                  .map((event) => (
                    <EventCard 
                      key={event.id} 
                      id={event.id}
                      title={event.title}
                      startDate={new Date(event.startDate)}
                      endDate={new Date(event.endDate)}
                      venue={event.venue}
                      attendees={0}
                      budget={Number(event.budget)}
                      status={event.status}
                      imageUrl={event.imageUrl || undefined}
                    />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="completed" className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredEvents
                  .filter((event) => event.status === "completed")
                  .map((event) => (
                    <EventCard 
                      key={event.id} 
                      id={event.id}
                      title={event.title}
                      startDate={new Date(event.startDate)}
                      endDate={new Date(event.endDate)}
                      venue={event.venue}
                      attendees={0}
                      budget={Number(event.budget)}
                      status={event.status}
                      imageUrl={event.imageUrl || undefined}
                    />
                  ))}
              </div>
            </TabsContent>
          </>
        )}
      </Tabs>
    </div>
  );
}
