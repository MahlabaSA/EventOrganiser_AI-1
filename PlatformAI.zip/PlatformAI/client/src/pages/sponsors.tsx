import { SponsorCard } from "@/components/sponsor-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, DollarSign, TrendingUp, Award } from "lucide-react";

// TODO: Remove mock data
const mockSponsors = [
  {
    id: "1",
    name: "TechCorp International",
    tier: "platinum" as const,
    package: "Platinum Plus",
    amount: 150000,
    roi: 340,
    leads: 248,
  },
  {
    id: "2",
    name: "GlobalSoft Solutions",
    tier: "gold" as const,
    package: "Gold Standard",
    amount: 75000,
    roi: 280,
    leads: 156,
  },
  {
    id: "3",
    name: "InnovateTech Inc",
    tier: "gold" as const,
    package: "Gold Standard",
    amount: 75000,
    roi: 310,
    leads: 189,
  },
  {
    id: "4",
    name: "DataVision Analytics",
    tier: "silver" as const,
    package: "Silver Package",
    amount: 35000,
    roi: 220,
    leads: 92,
  },
  {
    id: "5",
    name: "CloudFirst Systems",
    tier: "silver" as const,
    package: "Silver Package",
    amount: 35000,
    roi: 195,
    leads: 78,
  },
  {
    id: "6",
    name: "StartupHub Ventures",
    tier: "bronze" as const,
    package: "Bronze Basics",
    amount: 15000,
    roi: 180,
    leads: 45,
  },
];

export default function Sponsors() {
  const totalRevenue = mockSponsors.reduce((sum, s) => sum + s.amount, 0);
  const avgROI = Math.round(
    mockSponsors.reduce((sum, s) => sum + (s.roi || 0), 0) / mockSponsors.length
  );
  const totalLeads = mockSponsors.reduce((sum, s) => sum + (s.leads || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-semibold font-serif">Sponsors & Exhibitors</h1>
          <p className="text-muted-foreground mt-1">
            Manage partnerships and track sponsor ROI
          </p>
        </div>
        <Button data-testid="button-add-sponsor">
          <Plus className="h-4 w-4 mr-2" />
          Add Sponsor
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Revenue
            </CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              ${(totalRevenue / 1000).toFixed(0)}K
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              From {mockSponsors.length} sponsors
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Average ROI
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{avgROI}%</div>
            <p className="text-xs text-muted-foreground mt-1">
              AI-predicted sponsor value
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Leads
            </CardTitle>
            <Award className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{totalLeads}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Generated for sponsors
            </p>
          </CardContent>
        </Card>
      </div>

      <div>
        <h2 className="text-2xl font-semibold mb-4">Active Sponsors</h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {mockSponsors.map((sponsor) => (
            <SponsorCard key={sponsor.id} {...sponsor} />
          ))}
        </div>
      </div>
    </div>
  );
}
