import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Database,
  Trash2,
  Plus,
  RefreshCw,
  Code,
  PlayCircle,
  Beaker,
  Users,
  Calendar,
  Award,
  Clock,
  BarChart3
} from "lucide-react";
import type { Event, Attendee, Sponsor, Session } from "@shared/schema";

export default function TestingInterface() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");

  const { data: events = [] } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });

  const { data: attendees = [] } = useQuery<Attendee[]>({
    queryKey: ["/api/attendees"],
  });

  const { data: sponsors = [] } = useQuery<Sponsor[]>({
    queryKey: ["/api/sponsors"],
  });

  const generateTestDataMutation = useMutation({
    mutationFn: async () => {
      // Generate a test event
      const testEvent = await apiRequest("POST", "/api/events", {
        title: `Test Event ${Date.now()}`,
        description: "Auto-generated test event for QA purposes",
        startDate: new Date().toISOString(),
        endDate: new Date(Date.now() + 86400000 * 3).toISOString(),
        venue: "Virtual Testing Environment",
        budget: "50000",
        status: "planning",
      });

      return testEvent;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      toast({
        title: "Test Data Generated",
        description: "New test event created successfully",
      });
    },
  });

  const clearTestDataMutation = useMutation({
    mutationFn: async () => {
      const testEvents = events.filter(e => e.title.includes("Test Event"));
      await Promise.all(
        testEvents.map(event => apiRequest("DELETE", `/api/events/${event.id}`))
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      toast({
        title: "Test Data Cleared",
        description: "All test events have been removed",
      });
    },
  });

  const refreshAllDataMutation = useMutation({
    mutationFn: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["/api/events"] }),
        queryClient.invalidateQueries({ queryKey: ["/api/attendees"] }),
        queryClient.invalidateQueries({ queryKey: ["/api/sponsors"] }),
      ]);
    },
    onSuccess: () => {
      toast({
        title: "Data Refreshed",
        description: "All data has been reloaded from the database",
      });
    },
  });

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2" data-testid="heading-testing">
              <Beaker className="h-8 w-8" />
              QA Control Center
            </h1>
            <p className="text-muted-foreground mt-1">
              Testing interface for EventOrganiser.AI platform
            </p>
          </div>
          <Button
            onClick={() => refreshAllDataMutation.mutate()}
            variant="outline"
            data-testid="button-refresh-all"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh All
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5" data-testid="tabs-testing">
            <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
            <TabsTrigger value="data" data-testid="tab-data">Data Manager</TabsTrigger>
            <TabsTrigger value="scenarios" data-testid="tab-scenarios">Test Scenarios</TabsTrigger>
            <TabsTrigger value="api" data-testid="tab-api">API Testing</TabsTrigger>
            <TabsTrigger value="ai" data-testid="tab-ai">AI Playground</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Events</CardTitle>
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-events">{events.length}</div>
                  <p className="text-xs text-muted-foreground">
                    {events.filter(e => e.title.includes("Test")).length} test events
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Attendees</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-attendees">{attendees.length}</div>
                  <p className="text-xs text-muted-foreground">
                    Across all events
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Sponsors</CardTitle>
                  <Award className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-sponsors">{sponsors.length}</div>
                  <p className="text-xs text-muted-foreground">
                    Active partnerships
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Database Status</CardTitle>
                  <Database className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <Badge variant="default" data-testid="badge-db-status">Connected</Badge>
                  <p className="text-xs text-muted-foreground mt-2">
                    PostgreSQL (Neon)
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>System Health</CardTitle>
                <CardDescription>Real-time platform status and diagnostics</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                    <span className="text-sm">API Server</span>
                  </div>
                  <Badge variant="outline" data-testid="badge-api-status">Running</Badge>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                    <span className="text-sm">Database Connection</span>
                  </div>
                  <Badge variant="outline" data-testid="badge-db-connection">Active</Badge>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-yellow-500" />
                    <span className="text-sm">AI Services</span>
                  </div>
                  <Badge variant="outline" data-testid="badge-ai-status">Pending Setup</Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="data" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Data Management</CardTitle>
                <CardDescription>View and manage all entities in the database</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        Events ({events.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-48">
                        {events.length === 0 ? (
                          <p className="text-sm text-muted-foreground">No events found</p>
                        ) : (
                          <div className="space-y-2">
                            {events.map((event) => (
                              <div key={event.id} className="flex items-center justify-between p-2 border rounded-md">
                                <div>
                                  <p className="text-sm font-medium" data-testid={`event-${event.id}`}>{event.title}</p>
                                  <p className="text-xs text-muted-foreground">{event.venue}</p>
                                </div>
                                <Badge variant="outline">{event.status}</Badge>
                              </div>
                            ))}
                          </div>
                        )}
                      </ScrollArea>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        Attendees ({attendees.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-48">
                        {attendees.length === 0 ? (
                          <p className="text-sm text-muted-foreground">No attendees found</p>
                        ) : (
                          <div className="space-y-2">
                            {attendees.map((attendee) => (
                              <div key={attendee.id} className="flex items-center justify-between p-2 border rounded-md">
                                <div>
                                  <p className="text-sm font-medium" data-testid={`attendee-${attendee.id}`}>{attendee.name}</p>
                                  <p className="text-xs text-muted-foreground">{attendee.email}</p>
                                </div>
                                <Badge variant="outline">{attendee.status}</Badge>
                              </div>
                            ))}
                          </div>
                        )}
                      </ScrollArea>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2">
                        <Award className="h-4 w-4" />
                        Sponsors ({sponsors.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-48">
                        {sponsors.length === 0 ? (
                          <p className="text-sm text-muted-foreground">No sponsors found</p>
                        ) : (
                          <div className="space-y-2">
                            {sponsors.map((sponsor) => (
                              <div key={sponsor.id} className="flex items-center justify-between p-2 border rounded-md">
                                <div>
                                  <p className="text-sm font-medium" data-testid={`sponsor-${sponsor.id}`}>{sponsor.name}</p>
                                  <p className="text-xs text-muted-foreground">{sponsor.tier} Tier</p>
                                </div>
                                <Badge variant="outline">{sponsor.package}</Badge>
                              </div>
                            ))}
                          </div>
                        )}
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="scenarios" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Test Scenario Generator</CardTitle>
                <CardDescription>
                  Generate realistic test data for various event scenarios
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <Button
                    onClick={() => generateTestDataMutation.mutate()}
                    disabled={generateTestDataMutation.isPending}
                    className="h-24 flex-col gap-2"
                    data-testid="button-generate-test-data"
                  >
                    <Plus className="h-6 w-6" />
                    Generate Test Event
                  </Button>

                  <Button
                    onClick={() => clearTestDataMutation.mutate()}
                    disabled={clearTestDataMutation.isPending}
                    variant="destructive"
                    className="h-24 flex-col gap-2"
                    data-testid="button-clear-test-data"
                  >
                    <Trash2 className="h-6 w-6" />
                    Clear Test Data
                  </Button>
                </div>

                <Separator />

                <div className="space-y-2">
                  <h4 className="font-medium">Available Scenarios</h4>
                  <div className="grid gap-2">
                    <Card className="hover-elevate active-elevate-2 cursor-pointer">
                      <CardHeader className="py-3">
                        <CardTitle className="text-sm">Small Workshop (50 attendees)</CardTitle>
                      </CardHeader>
                    </Card>
                    <Card className="hover-elevate active-elevate-2 cursor-pointer">
                      <CardHeader className="py-3">
                        <CardTitle className="text-sm">Medium Conference (500 attendees)</CardTitle>
                      </CardHeader>
                    </Card>
                    <Card className="hover-elevate active-elevate-2 cursor-pointer">
                      <CardHeader className="py-3">
                        <CardTitle className="text-sm">Large Expo (2000+ attendees)</CardTitle>
                      </CardHeader>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="api" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>API Endpoint Testing</CardTitle>
                <CardDescription>Test and monitor API endpoints</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {[
                    { method: "GET", endpoint: "/api/events", description: "Get all events" },
                    { method: "POST", endpoint: "/api/events", description: "Create new event" },
                    { method: "GET", endpoint: "/api/attendees", description: "Get all attendees" },
                    { method: "GET", endpoint: "/api/sponsors", description: "Get all sponsors" },
                    { method: "GET", endpoint: "/api/analytics", description: "Get analytics data" },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 border rounded-md">
                      <div className="flex items-center gap-3">
                        <Badge
                          variant={api.method === "GET" ? "default" : "outline"}
                          data-testid={`badge-method-${idx}`}
                        >
                          {api.method}
                        </Badge>
                        <div>
                          <code className="text-sm" data-testid={`endpoint-${idx}`}>{api.endpoint}</code>
                          <p className="text-xs text-muted-foreground">{api.description}</p>
                        </div>
                      </div>
                      <Button size="sm" variant="outline" data-testid={`button-test-${idx}`}>
                        <PlayCircle className="h-4 w-4 mr-1" />
                        Test
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ai" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>AI Feature Playground</CardTitle>
                <CardDescription>
                  Test AI-powered features and content generation
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center py-12">
                  <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">AI Integration Pending</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    OpenAI integration required to test AI features
                  </p>
                  <Badge variant="outline" data-testid="badge-ai-integration">Coming Soon</Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
