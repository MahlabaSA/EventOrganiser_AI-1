# EventOrganiser.AI Design Guidelines

## Design Approach
**Selected Approach:** Design System with Enterprise SaaS Influence

**Justification:** This is a utility-focused, data-intensive enterprise platform requiring efficiency, clarity, and professional polish. Drawing inspiration from Linear (clean dashboard aesthetics), Notion (intuitive information hierarchy), and Material Design (robust data visualization components) to create a system optimized for complex workflows and analytics-heavy interfaces.

**Core Principles:**
- Clarity over creativity - every element serves function
- Scannable information hierarchy for quick decision-making
- Consistent patterns across all modules for learnability
- Professional, trustworthy aesthetic for Fortune 500 clients

## Typography

**Font Stack:**
- Primary: Inter (via Google Fonts CDN) - all UI elements, body text, tables
- Accent: Space Grotesk (via Google Fonts CDN) - large headings, hero sections only

**Hierarchy:**
- Dashboard Titles: text-4xl font-semibold (Space Grotesk)
- Section Headers: text-2xl font-semibold (Inter)
- Card Headers: text-lg font-medium (Inter)
- Body/Tables: text-sm font-normal (Inter)
- Labels: text-xs font-medium uppercase tracking-wide (Inter)
- Metrics/Stats: text-3xl font-bold (Inter)

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16, 24
- Component padding: p-4 to p-8
- Section spacing: gap-6 to gap-8
- Page margins: p-6 to p-12
- Card spacing: p-6
- Form fields: gap-4

**Grid Structure:**
- Dashboard: 12-column grid with gap-6
- Main content area: max-w-7xl mx-auto
- Sidebar navigation: fixed w-64
- Cards/Widgets: Grid-based (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)

## Component Library

### Navigation & Structure
- **Top Navigation Bar:** Full-width, includes logo, global search, notifications, user profile. Height h-16, subtle border-b
- **Sidebar Navigation:** Fixed left sidebar (w-64) with collapsible sections, icon + label pattern. Includes role-based menu items
- **Breadcrumbs:** Always present for deep navigation context

### Dashboard Components
- **Metric Cards:** Grid layout showcasing KPIs (forecasted attendance, revenue, engagement). Large number display with trend indicators and sparkline charts
- **Analytics Charts:** Line charts for trends, bar charts for comparisons, donut charts for distributions using Chart.js or Recharts
- **Data Tables:** Sortable, filterable tables with row actions, pagination, and export functionality
- **Timeline View:** Vertical timeline for event phases and milestones
- **Status Badges:** Pill-shaped indicators for event status, registration status, task completion

### Event Management
- **Event Card:** Thumbnail image (if available), event name, date range, venue, key metrics, action buttons
- **Calendar Integration:** Month/week/day views with drag-and-drop scheduling
- **Session Builder:** Drag-and-drop interface for agenda creation with conflict detection visual indicators
- **Venue Designer Preview:** 2D/3D viewport area for digital twin visualization with toolbar controls

### AI Features
- **AI Assistant Panel:** Slide-out panel (w-96) from right side with chat interface for AI-generated content
- **Prediction Cards:** Display forecasted metrics with confidence intervals and historical comparison
- **Recommendation Widgets:** Suggested actions, optimizations, or insights with "Accept/Dismiss" actions

### Forms & Inputs
- **Form Layout:** Two-column layout (lg:grid-cols-2) for registration, event creation. Single column for focused tasks
- **Input Fields:** Consistent height (h-12), clear labels above, helper text below
- **File Upload:** Drag-and-drop zone with preview thumbnails
- **Multi-step Forms:** Progress indicator at top, clear navigation between steps

### User & Role Management
- **User Profile Cards:** Avatar, name, role badge, contact info, action menu
- **Permission Matrix:** Table showing role-based access controls with toggle switches
- **Attendee List:** Searchable, filterable list with bulk actions toolbar

### Operations Dashboard
- **Real-time Metrics:** Large display cards with auto-refreshing data, visual alerts for anomalies
- **Command Center View:** Split-screen with live event feed on left, metrics/controls on right
- **Alert System:** Toast notifications for critical updates, modal for action-required alerts

### Sponsor & Exhibitor Portal
- **Package Builder:** Visual package creation with drag-drop benefits, pricing calculator
- **ROI Dashboard:** Dedicated analytics showing sponsor value metrics, lead generation data

### Post-Event
- **Feedback Collection:** Survey builder with various question types, response visualization
- **Engagement Heatmaps:** Visual representation of session attendance, booth traffic
- **Report Generator:** Template selection, data filtering, export options (PDF, Excel)

### Supporting Elements
- **Loading States:** Skeleton screens for data-heavy components, spinner for quick actions
- **Empty States:** Illustrated empty states with clear CTAs to guide user actions
- **Modals/Dialogs:** Centered overlays with backdrop blur, clear close actions
- **Icons:** Heroicons throughout for consistency, 20px for inline, 24px for standalone

## Images

**Hero Section (Marketing Pages Only):**
- Large hero image showing event/conference setting or team collaboration
- Positioned as background with overlay gradient for text legibility
- Buttons with backdrop-blur-md treatment

**Dashboard/Platform:**
- No hero images in application views
- Event thumbnail images (16:9 aspect ratio) in cards
- Avatar images for users/attendees (circular, consistent sizing)
- Placeholder illustrations for empty states only

## Page Structures

**Landing Page:** Hero with platform demo screenshot, feature grid (3 columns), client logos, pricing comparison table, CTA section

**Dashboard:** Sidebar + top nav, metric cards row, charts grid (2 columns), recent events table, quick actions panel

**Event Detail:** Header with event image and key info, tabbed interface (Overview, Agenda, Attendees, Sponsors, Analytics), contextual action bar

**Analytics View:** Full-width charts area, filter sidebar, export toolbar, multiple visualization types stacked vertically