import { readFileSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import { db } from "./db";
import { sql } from "drizzle-orm";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

async function applyTriggers() {
  console.log("🔒 Applying multi-tenant isolation triggers...");
  
  try {
    // Read the SQL file
    const triggerSQL = readFileSync(
      join(__dirname, "migrations/multi-tenant-triggers.sql"),
      "utf-8"
    );

    // Execute the SQL
    await db.execute(sql.raw(triggerSQL));

    console.log("✅ Multi-tenant triggers applied successfully!");
    console.log("\n📋 Trigger Summary:");
    console.log("   - User assignment validation (projects, tasks, risks, events, venue_layouts)");
    console.log("   - Parent-child organization matching (all child tables)");
    console.log("   - Cross-tenant access prevention enforced at database level");
    
  } catch (error) {
    console.error("❌ Failed to apply triggers:", error);
    throw error;
  } finally {
    process.exit(0);
  }
}

applyTriggers();
