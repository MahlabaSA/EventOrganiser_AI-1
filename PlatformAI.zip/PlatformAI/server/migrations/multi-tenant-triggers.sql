-- Multi-Tenant Isolation Enforcement Triggers
-- This file must be run after schema creation to enforce database-level tenant isolation
-- Required for production deployment - prevents cross-organization data exposure

-- ============================================================================
-- TRIGGER FUNCTIONS
-- ============================================================================

-- Validate user assignments for projects table (project_manager)
CREATE OR REPLACE FUNCTION validate_projects_users()
RETURNS TRIGGER AS $$
DECLARE
  user_org_id VARCHAR;
BEGIN
  IF NEW.project_manager IS NOT NULL THEN
    SELECT organization_id INTO user_org_id FROM users WHERE id = NEW.project_manager;
    IF user_org_id IS NULL THEN
      RAISE EXCEPTION 'User % does not exist', NEW.project_manager;
    END IF;
    IF user_org_id != NEW.organization_id THEN
      RAISE EXCEPTION 'Cannot assign project manager from different organization';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Validate user assignments for tasks table (assigned_to, created_by)
CREATE OR REPLACE FUNCTION validate_tasks_users()
RETURNS TRIGGER AS $$
DECLARE
  user_org_id VARCHAR;
BEGIN
  IF NEW.assigned_to IS NOT NULL THEN
    SELECT organization_id INTO user_org_id FROM users WHERE id = NEW.assigned_to;
    IF user_org_id IS NULL THEN
      RAISE EXCEPTION 'User % does not exist', NEW.assigned_to;
    END IF;
    IF user_org_id != NEW.organization_id THEN
      RAISE EXCEPTION 'Cannot assign task to user from different organization';
    END IF;
  END IF;
  IF NEW.created_by IS NOT NULL THEN
    SELECT organization_id INTO user_org_id FROM users WHERE id = NEW.created_by;
    IF user_org_id IS NULL THEN
      RAISE EXCEPTION 'User % does not exist', NEW.created_by;
    END IF;
    IF user_org_id != NEW.organization_id THEN
      RAISE EXCEPTION 'Cannot set createdBy to user from different organization';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Validate user assignments for risks table (owner, created_by)
CREATE OR REPLACE FUNCTION validate_risks_users()
RETURNS TRIGGER AS $$
DECLARE
  user_org_id VARCHAR;
BEGIN
  IF NEW.owner IS NOT NULL THEN
    SELECT organization_id INTO user_org_id FROM users WHERE id = NEW.owner;
    IF user_org_id IS NULL THEN
      RAISE EXCEPTION 'User % does not exist', NEW.owner;
    END IF;
    IF user_org_id != NEW.organization_id THEN
      RAISE EXCEPTION 'Cannot assign risk owner from different organization';
    END IF;
  END IF;
  IF NEW.created_by IS NOT NULL THEN
    SELECT organization_id INTO user_org_id FROM users WHERE id = NEW.created_by;
    IF user_org_id IS NULL THEN
      RAISE EXCEPTION 'User % does not exist', NEW.created_by;
    END IF;
    IF user_org_id != NEW.organization_id THEN
      RAISE EXCEPTION 'Cannot set createdBy to user from different organization';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Validate user assignments for events/venue_layouts (created_by only)
CREATE OR REPLACE FUNCTION validate_created_by_user()
RETURNS TRIGGER AS $$
DECLARE
  user_org_id VARCHAR;
BEGIN
  IF NEW.created_by IS NOT NULL THEN
    SELECT organization_id INTO user_org_id FROM users WHERE id = NEW.created_by;
    IF user_org_id IS NULL THEN
      RAISE EXCEPTION 'User % does not exist', NEW.created_by;
    END IF;
    IF user_org_id != NEW.organization_id THEN
      RAISE EXCEPTION 'Cannot set createdBy to user from different organization';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Validate parent-child organization match
CREATE OR REPLACE FUNCTION validate_parent_organization()
RETURNS TRIGGER AS $$
DECLARE
  parent_org_id VARCHAR;
BEGIN
  -- For events, check project organization (only if project is specified)
  IF TG_TABLE_NAME = 'events' AND NEW.project_id IS NOT NULL THEN
    SELECT organization_id INTO parent_org_id FROM projects WHERE id = NEW.project_id;
    IF parent_org_id IS NULL THEN
      RAISE EXCEPTION 'Project % does not exist', NEW.project_id;
    END IF;
    IF parent_org_id != NEW.organization_id THEN
      RAISE EXCEPTION 'Event organizationId must match project organizationId (event org: %, project org: %)', NEW.organization_id, parent_org_id;
    END IF;
  END IF;

  -- For tasks, check project organization
  IF TG_TABLE_NAME = 'tasks' THEN
    SELECT organization_id INTO parent_org_id FROM projects WHERE id = NEW.project_id;
    IF parent_org_id IS NULL THEN
      RAISE EXCEPTION 'Project % does not exist', NEW.project_id;
    END IF;
    IF parent_org_id != NEW.organization_id THEN
      RAISE EXCEPTION 'Task organizationId must match project organizationId (task org: %, project org: %)', NEW.organization_id, parent_org_id;
    END IF;
  END IF;

  -- For risks, check project organization
  IF TG_TABLE_NAME = 'risks' THEN
    SELECT organization_id INTO parent_org_id FROM projects WHERE id = NEW.project_id;
    IF parent_org_id IS NULL THEN
      RAISE EXCEPTION 'Project % does not exist', NEW.project_id;
    END IF;
    IF parent_org_id != NEW.organization_id THEN
      RAISE EXCEPTION 'Risk organizationId must match project organizationId (risk org: %, project org: %)', NEW.organization_id, parent_org_id;
    END IF;
  END IF;

  -- For sessions, check event organization
  IF TG_TABLE_NAME = 'sessions' THEN
    SELECT organization_id INTO parent_org_id FROM events WHERE id = NEW.event_id;
    IF parent_org_id IS NULL THEN
      RAISE EXCEPTION 'Event % does not exist', NEW.event_id;
    END IF;
    IF parent_org_id != NEW.organization_id THEN
      RAISE EXCEPTION 'Session organizationId must match event organizationId (session org: %, event org: %)', NEW.organization_id, parent_org_id;
    END IF;
  END IF;

  -- For attendees, sponsors, analytics, venueLayouts check event organization
  IF TG_TABLE_NAME IN ('attendees', 'sponsors', 'analytics', 'venue_layouts') THEN
    SELECT organization_id INTO parent_org_id FROM events WHERE id = NEW.event_id;
    IF parent_org_id IS NULL THEN
      RAISE EXCEPTION 'Event % does not exist', NEW.event_id;
    END IF;
    IF parent_org_id != NEW.organization_id THEN
      RAISE EXCEPTION '% organizationId must match event organizationId (record org: %, event org: %)', TG_TABLE_NAME, NEW.organization_id, parent_org_id;
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- TRIGGER ATTACHMENTS
-- ============================================================================

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS validate_projects_users_org ON projects;
DROP TRIGGER IF EXISTS validate_tasks_users_org ON tasks;
DROP TRIGGER IF EXISTS validate_risks_users_org ON risks;
DROP TRIGGER IF EXISTS validate_events_users_org ON events;
DROP TRIGGER IF EXISTS validate_venue_layouts_users_org ON venue_layouts;

DROP TRIGGER IF EXISTS validate_events_parent_org ON events;
DROP TRIGGER IF EXISTS validate_tasks_parent_org ON tasks;
DROP TRIGGER IF EXISTS validate_risks_parent_org ON risks;
DROP TRIGGER IF EXISTS validate_sessions_parent_org ON sessions;
DROP TRIGGER IF EXISTS validate_attendees_parent_org ON attendees;
DROP TRIGGER IF EXISTS validate_sponsors_parent_org ON sponsors;
DROP TRIGGER IF EXISTS validate_analytics_parent_org ON analytics;
DROP TRIGGER IF EXISTS validate_venue_layouts_parent_org ON venue_layouts;

-- Apply user validation triggers (unique names per table)
CREATE TRIGGER validate_projects_users_org
  BEFORE INSERT OR UPDATE ON projects
  FOR EACH ROW
  EXECUTE FUNCTION validate_projects_users();

CREATE TRIGGER validate_tasks_users_org
  BEFORE INSERT OR UPDATE ON tasks
  FOR EACH ROW
  EXECUTE FUNCTION validate_tasks_users();

CREATE TRIGGER validate_risks_users_org
  BEFORE INSERT OR UPDATE ON risks
  FOR EACH ROW
  EXECUTE FUNCTION validate_risks_users();

CREATE TRIGGER validate_events_users_org
  BEFORE INSERT OR UPDATE ON events
  FOR EACH ROW
  EXECUTE FUNCTION validate_created_by_user();

CREATE TRIGGER validate_venue_layouts_users_org
  BEFORE INSERT OR UPDATE ON venue_layouts
  FOR EACH ROW
  EXECUTE FUNCTION validate_created_by_user();

-- Apply parent-child organization validation triggers (unique names per table)
CREATE TRIGGER validate_events_parent_org
  BEFORE INSERT OR UPDATE ON events
  FOR EACH ROW
  EXECUTE FUNCTION validate_parent_organization();

CREATE TRIGGER validate_tasks_parent_org
  BEFORE INSERT OR UPDATE ON tasks
  FOR EACH ROW
  EXECUTE FUNCTION validate_parent_organization();

CREATE TRIGGER validate_risks_parent_org
  BEFORE INSERT OR UPDATE ON risks
  FOR EACH ROW
  EXECUTE FUNCTION validate_parent_organization();

CREATE TRIGGER validate_sessions_parent_org
  BEFORE INSERT OR UPDATE ON sessions
  FOR EACH ROW
  EXECUTE FUNCTION validate_parent_organization();

CREATE TRIGGER validate_attendees_parent_org
  BEFORE INSERT OR UPDATE ON attendees
  FOR EACH ROW
  EXECUTE FUNCTION validate_parent_organization();

CREATE TRIGGER validate_sponsors_parent_org
  BEFORE INSERT OR UPDATE ON sponsors
  FOR EACH ROW
  EXECUTE FUNCTION validate_parent_organization();

CREATE TRIGGER validate_analytics_parent_org
  BEFORE INSERT OR UPDATE ON analytics
  FOR EACH ROW
  EXECUTE FUNCTION validate_parent_organization();

CREATE TRIGGER validate_venue_layouts_parent_org
  BEFORE INSERT OR UPDATE ON venue_layouts
  FOR EACH ROW
  EXECUTE FUNCTION validate_parent_organization();

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Verify triggers are installed
SELECT 
  n.nspname as schema_name,
  c.relname as table_name,
  count(*) as trigger_count
FROM pg_trigger t
JOIN pg_class c ON t.tgrelid = c.oid
JOIN pg_namespace n ON c.relnamespace = n.oid
WHERE n.nspname = 'public' 
  AND c.relname IN ('projects', 'tasks', 'risks', 'events', 'venue_layouts', 'sessions', 'attendees', 'sponsors', 'analytics')
  AND NOT tgisinternal
GROUP BY n.nspname, c.relname
ORDER BY c.relname;
