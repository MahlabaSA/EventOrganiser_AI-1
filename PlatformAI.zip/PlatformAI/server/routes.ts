import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertEventSchema, 
  insertAttendeeSchema, 
  insertSponsorSchema,
  insertSessionSchema,
  insertAnalyticsSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Events
  app.get("/api/events", async (req, res) => {
    try {
      const events = await storage.getEvents();
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch events" });
    }
  });

  app.get("/api/events/:id", async (req, res) => {
    try {
      const event = await storage.getEvent(req.params.id);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.json(event);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch event" });
    }
  });

  app.post("/api/events", async (req, res) => {
    try {
      const validatedData = insertEventSchema.parse(req.body);
      const event = await storage.createEvent(validatedData);
      res.status(201).json(event);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid event data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create event" });
    }
  });

  app.patch("/api/events/:id", async (req, res) => {
    try {
      const updateSchema = insertEventSchema.partial();
      const validatedData = updateSchema.parse(req.body);
      const event = await storage.updateEvent(req.params.id, validatedData);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.json(event);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid event data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update event" });
    }
  });

  app.delete("/api/events/:id", async (req, res) => {
    try {
      await storage.deleteEvent(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete event" });
    }
  });

  // Attendees
  app.get("/api/events/:eventId/attendees", async (req, res) => {
    try {
      const attendees = await storage.getAttendees(req.params.eventId);
      res.json(attendees);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch attendees" });
    }
  });

  app.post("/api/attendees", async (req, res) => {
    try {
      const validatedData = insertAttendeeSchema.parse(req.body);
      const attendee = await storage.createAttendee(validatedData);
      res.status(201).json(attendee);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid attendee data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create attendee" });
    }
  });

  app.patch("/api/attendees/:id/check-in", async (req, res) => {
    try {
      const attendee = await storage.checkInAttendee(req.params.id);
      if (!attendee) {
        return res.status(404).json({ error: "Attendee not found" });
      }
      res.json(attendee);
    } catch (error) {
      res.status(500).json({ error: "Failed to check in attendee" });
    }
  });

  // Sponsors
  app.get("/api/events/:eventId/sponsors", async (req, res) => {
    try {
      const sponsors = await storage.getSponsors(req.params.eventId);
      res.json(sponsors);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sponsors" });
    }
  });

  app.post("/api/sponsors", async (req, res) => {
    try {
      const validatedData = insertSponsorSchema.parse(req.body);
      const sponsor = await storage.createSponsor(validatedData);
      res.status(201).json(sponsor);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid sponsor data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create sponsor" });
    }
  });

  app.patch("/api/sponsors/:id", async (req, res) => {
    try {
      const updateSchema = insertSponsorSchema.partial();
      const validatedData = updateSchema.parse(req.body);
      const sponsor = await storage.updateSponsor(req.params.id, validatedData);
      if (!sponsor) {
        return res.status(404).json({ error: "Sponsor not found" });
      }
      res.json(sponsor);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid sponsor data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update sponsor" });
    }
  });

  // Sessions
  app.get("/api/events/:eventId/sessions", async (req, res) => {
    try {
      const sessions = await storage.getSessions(req.params.eventId);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sessions" });
    }
  });

  app.post("/api/sessions", async (req, res) => {
    try {
      const validatedData = insertSessionSchema.parse(req.body);
      const session = await storage.createSession(validatedData);
      res.status(201).json(session);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid session data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create session" });
    }
  });

  app.patch("/api/sessions/:id", async (req, res) => {
    try {
      const updateSchema = insertSessionSchema.partial();
      const validatedData = updateSchema.parse(req.body);
      const session = await storage.updateSession(req.params.id, validatedData);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid session data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update session" });
    }
  });

  app.delete("/api/sessions/:id", async (req, res) => {
    try {
      await storage.deleteSession(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete session" });
    }
  });

  // Analytics
  app.get("/api/events/:eventId/analytics", async (req, res) => {
    try {
      const analyticsData = await storage.getAnalytics(req.params.eventId);
      res.json(analyticsData);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  app.post("/api/analytics", async (req, res) => {
    try {
      const validatedData = insertAnalyticsSchema.parse(req.body);
      const analyticsRecord = await storage.createAnalytics(validatedData);
      res.status(201).json(analyticsRecord);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid analytics data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create analytics record" });
    }
  });

  // AI Assistant endpoint (placeholder for OpenAI integration)
  app.post("/api/ai/generate", async (req, res) => {
    try {
      const { prompt, type } = req.body;
      
      // TODO: Integrate with OpenAI API
      // For now, return a placeholder response
      const response = {
        content: `AI-generated response for: ${prompt}. This will be powered by OpenAI in the full implementation.`,
        type,
      };
      
      res.json(response);
    } catch (error) {
      res.status(500).json({ error: "Failed to generate AI content" });
    }
  });

  // Dashboard stats endpoint
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const events = await storage.getEvents();
      
      // Calculate aggregate stats
      const stats = {
        totalEvents: events.length,
        activeEvents: events.filter(e => e.status === "active").length,
        totalAttendees: 0, // Would calculate from all attendees
        totalRevenue: 0,   // Would calculate from all events
        engagementRate: 87, // Placeholder
      };

      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
