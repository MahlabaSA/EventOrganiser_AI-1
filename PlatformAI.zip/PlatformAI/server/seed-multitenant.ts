import { db } from "./db";
import { organizations, users, projects, events, tasks, risks, speakers, attendees, sponsors, sessions, analytics, venueLayouts } from "@shared/schema";

async function seed() {
  console.log("🌱 Seeding multi-tenant database...");

  // Clear existing data
  console.log("Clearing existing data...");
  await db.delete(analytics);
  await db.delete(venueLayouts);
  await db.delete(sessions);
  await db.delete(sponsors);
  await db.delete(attendees);
  await db.delete(risks);
  await db.delete(tasks);
  await db.delete(events);
  await db.delete(speakers);
  await db.delete(projects);
  await db.delete(users);
  await db.delete(organizations);
  console.log("✓ Cleared existing data");

  // Create default organization
  const [org] = await db.insert(organizations).values({
    name: "Moya Events Demo",
    domain: "moyaevents.com",
    tier: "enterprise",
    active: true,
  }).returning();

  console.log("✓ Created organization:", org.name);

  // Create users
  const [admin] = await db.insert(users).values([
    {
      organizationId: org.id,
      email: "admin@moyaevents.com",
      firstName: "Sarah",
      lastName: "Johnson",
      role: "admin",
      company: "Moya Events",
      active: true,
    },
    {
      organizationId: org.id,
      email: "pm@moyaevents.com",
      firstName: "Michael",
      lastName: "Chen",
      role: "project_manager",
      company: "Moya Events",
      active: true,
    },
    {
      organizationId: org.id,
      email: "coordinator@moyaevents.com",
      firstName: "Emily",
      lastName: "Rodriguez",
      role: "coordinator",
      company: "Moya Events",
      active: true,
    },
  ]).returning();

  console.log("✓ Created 3 users");

  // Create PMBOK-aligned project
  const [project1] = await db.insert(projects).values({
    organizationId: org.id,
    name: "Global Tech Summit 2025",
    description: "Major technology conference for Fortune 500 clients",
    status: "executing",
    startDate: new Date("2025-06-01"),
    endDate: new Date("2025-06-15"),
    budget: "500000",
    projectManager: admin.id,
    createdBy: admin.id,
  }).returning();

  console.log("✓ Created project:", project1.name);

  // Create events linked to project
  const [event1, event2] = await db.insert(events).values([
    {
      organizationId: org.id,
      projectId: project1.id,
      title: "AI & Innovation Summit",
      description: "Explore the future of artificial intelligence and digital transformation",
      startDate: new Date("2025-03-15"),
      endDate: new Date("2025-03-17"),
      venue: "San Francisco Convention Center",
      budget: "250000",
      status: "active",
      createdBy: admin.id,
    },
    {
      organizationId: org.id,
      projectId: project1.id,
      title: "Sustainability in Tech Conference",
      description: "Leading enterprises discuss sustainable technology practices",
      startDate: new Date("2025-05-20"),
      endDate: new Date("2025-05-22"),
      venue: "Seattle Convention Center",
      budget: "180000",
      status: "planning",
      createdBy: admin.id,
    },
  ]).returning();

  console.log("✓ Created 2 events");

  // Create tasks for the project
  await db.insert(tasks).values([
    {
      organizationId: org.id,
      projectId: project1.id,
      title: "Finalize venue contracts",
      description: "Sign agreements with convention centers",
      status: "completed",
      priority: "high",
      assignedTo: admin.id,
      dueDate: new Date("2025-01-31"),
      createdBy: admin.id,
    },
    {
      organizationId: org.id,
      projectId: project1.id,
      title: "Launch marketing campaign",
      description: "Deploy social media and email campaigns",
      status: "in_progress",
      priority: "high",
      assignedTo: admin.id,
      dueDate: new Date("2025-02-15"),
      createdBy: admin.id,
    },
    {
      organizationId: org.id,
      projectId: project1.id,
      title: "Confirm keynote speakers",
      description: "Secure commitments from industry leaders",
      status: "todo",
      priority: "critical",
      assignedTo: admin.id,
      dueDate: new Date("2025-02-28"),
      createdBy: admin.id,
    },
  ]);

  console.log("✓ Created 3 tasks");

  // Create ISO 31000 risk register (AI-generated example)
  await db.insert(risks).values([
    {
      organizationId: org.id,
      projectId: project1.id,
      category: "financial",
      title: "Budget Overrun Risk",
      description: "Potential for expenses to exceed allocated budget due to vendor price increases",
      likelihood: "possible",
      impact: "major",
      riskScore: 15,
      mitigationPlan: "Implement strict budget controls, negotiate fixed-price contracts, maintain 10% contingency reserve",
      owner: admin.id,
      status: "open",
      aiGenerated: true,
      createdBy: admin.id,
    },
    {
      organizationId: org.id,
      projectId: project1.id,
      category: "operational",
      title: "Speaker Cancellation Risk",
      description: "Key speakers may withdraw, impacting event quality and attendee satisfaction",
      likelihood: "unlikely",
      impact: "moderate",
      riskScore: 6,
      mitigationPlan: "Maintain backup speaker list, include cancellation clauses in contracts",
      owner: admin.id,
      status: "open",
      aiGenerated: true,
      createdBy: admin.id,
    },
    {
      organizationId: org.id,
      projectId: project1.id,
      category: "cybersecurity",
      title: "Data Breach During Registration",
      description: "Risk of attendee data compromise during online registration process",
      likelihood: "rare",
      impact: "catastrophic",
      riskScore: 10,
      mitigationPlan: "Implement ISO 27001 controls, use encrypted registration platform, conduct security audits",
      owner: admin.id,
      status: "open",
      aiGenerated: true,
      createdBy: admin.id,
    },
  ]);

  console.log("✓ Created 3 AI-generated risks (ISO 31000)");

  // Create speakers
  const [speaker1, speaker2] = await db.insert(speakers).values([
    {
      organizationId: org.id,
      name: "Dr. Lisa Zhang",
      email: "lzhang@example.com",
      bio: "Leading AI researcher and founder of AI Ethics Institute",
      title: "Chief AI Officer",
      company: "TechVision Corp",
      expertise: ["Artificial Intelligence", "Machine Learning", "Ethics"],
      linkedinUrl: "https://linkedin.com/in/lisazhang",
      twitterHandle: "@lisazhang",
    },
    {
      organizationId: org.id,
      name: "Mark Sullivan",
      email: "msullivan@example.com",
      bio: "Sustainability expert with 15+ years in green technology",
      title: "VP of Sustainability",
      company: "EcoTech Solutions",
      expertise: ["Sustainability", "Green Tech", "ESG"],
      linkedinUrl: "https://linkedin.com/in/marksullivan",
    },
  ]).returning();

  console.log("✓ Created 2 speakers");

  // Create sessions
  await db.insert(sessions).values([
    {
      organizationId: org.id,
      eventId: event1.id,
      speakerId: speaker1.id,
      title: "The Future of AI Governance",
      speaker: speaker1.name,
      startTime: "09:00",
      duration: 60,
      capacity: 500,
      track: "AI & Ethics",
      description: "Exploring frameworks for responsible AI development",
      aiGenerated: false,
    },
    {
      organizationId: org.id,
      eventId: event2.id,
      speakerId: speaker2.id,
      title: "Building Carbon-Neutral Data Centers",
      speaker: speaker2.name,
      startTime: "14:00",
      duration: 45,
      capacity: 300,
      track: "Sustainability",
      description: "Case studies from leading tech companies",
      aiGenerated: false,
    },
  ]);

  console.log("✓ Created 2 sessions");

  // Create attendees with payment status
  await db.insert(attendees).values([
    {
      organizationId: org.id,
      eventId: event1.id,
      name: "John Smith",
      email: "john.smith@example.com",
      company: "Acme Corp",
      ticketType: "VIP",
      ticketPrice: "999.00",
      paymentStatus: "paid",
      status: "registered",
    },
    {
      organizationId: org.id,
      eventId: event1.id,
      name: "Jane Doe",
      email: "jane.doe@example.com",
      company: "Global Tech Inc",
      ticketType: "Standard",
      ticketPrice: "499.00",
      paymentStatus: "paid",
      status: "registered",
    },
    {
      organizationId: org.id,
      eventId: event2.id,
      name: "Bob Wilson",
      email: "bob.wilson@example.com",
      company: "Green Energy Ltd",
      ticketType: "Early Bird",
      ticketPrice: "399.00",
      paymentStatus: "pending",
      status: "registered",
    },
  ]);

  console.log("✓ Created 3 attendees");

  // Create sponsors
  await db.insert(sponsors).values([
    {
      organizationId: org.id,
      eventId: event1.id,
      name: "Microsoft",
      tier: "platinum",
      package: "Premier",
      amount: "50000",
      roi: 250,
      leads: 450,
    },
    {
      organizationId: org.id,
      eventId: event1.id,
      name: "AWS",
      tier: "gold",
      package: "Standard",
      amount: "25000",
      roi: 180,
      leads: 280,
    },
    {
      organizationId: org.id,
      eventId: event2.id,
      name: "Tesla",
      tier: "platinum",
      package: "Sustainability Leader",
      amount: "75000",
      roi: 300,
      leads: 520,
    },
  ]);

  console.log("✓ Created 3 sponsors");

  console.log("\n✅ Multi-tenant database seeded successfully!");
  console.log(`\n📊 Summary:`);
  console.log(`   - 1 organization (${org.name})`);
  console.log(`   - 3 users (admin, PM, coordinator)`);
  console.log(`   - 1 PMBOK project`);
  console.log(`   - 2 events`);
  console.log(`   - 3 tasks`);
  console.log(`   - 3 ISO 31000 risks (AI-generated)`);
  console.log(`   - 2 speakers`);
  console.log(`   - 2 sessions`);
  console.log(`   - 3 attendees`);
  console.log(`   - 3 sponsors`);

  process.exit(0);
}

seed().catch((error) => {
  console.error("❌ Seeding failed:", error);
  process.exit(1);
});
