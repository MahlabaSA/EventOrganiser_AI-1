import { db } from "./db";
import { events, attendees, sponsors, sessions, analytics } from "@shared/schema";

async function seed() {
  console.log("Seeding database...");

  // Create sample events
  const event1 = await db.insert(events).values({
    title: "Global Tech Summit 2025",
    description: "The premier technology conference bringing together innovators from around the world",
    startDate: new Date("2025-03-15"),
    endDate: new Date("2025-03-17"),
    venue: "Cape Town Convention Centre, South Africa",
    budget: "450000",
    status: "planning",
  }).returning();

  const event2 = await db.insert(events).values({
    title: "Annual Leadership Conference",
    description: "Empowering leaders to drive organizational excellence",
    startDate: new Date("2025-04-10"),
    endDate: new Date("2025-04-12"),
    venue: "Sandton Convention Centre, Johannesburg",
    budget: "280000",
    status: "active",
  }).returning();

  const event3 = await db.insert(events).values({
    title: "Innovation & AI Expo",
    description: "Exploring the future of artificial intelligence and innovation",
    startDate: new Date("2025-05-20"),
    endDate: new Date("2025-05-22"),
    venue: "Durban ICC, South Africa",
    budget: "520000",
    status: "planning",
  }).returning();

  console.log(`Created ${3} events`);

  // Create sample attendees for event1
  await db.insert(attendees).values([
    {
      eventId: event1[0].id,
      name: "Sarah Johnson",
      email: "sarah.johnson@techcorp.com",
      company: "TechCorp Global",
      ticketType: "VIP Pass",
      status: "checked-in",
    },
    {
      eventId: event1[0].id,
      name: "Michael Chen",
      email: "m.chen@innovate.io",
      company: "Innovate Solutions",
      ticketType: "Standard",
      status: "registered",
    },
    {
      eventId: event1[0].id,
      name: "Emily Rodriguez",
      email: "emily.r@futuretech.com",
      company: "FutureTech Inc",
      ticketType: "Premium",
      status: "checked-in",
    },
  ]);

  console.log(`Created ${3} attendees for event 1`);

  // Create sample sponsors for event1
  await db.insert(sponsors).values([
    {
      eventId: event1[0].id,
      name: "TechCorp International",
      tier: "platinum",
      package: "Platinum Plus",
      amount: "150000",
      roi: 340,
      leads: 248,
    },
    {
      eventId: event1[0].id,
      name: "GlobalSoft Solutions",
      tier: "gold",
      package: "Gold Standard",
      amount: "75000",
      roi: 280,
      leads: 156,
    },
  ]);

  console.log(`Created ${2} sponsors for event 1`);

  // Create sample sessions for event1
  await db.insert(sessions).values([
    {
      eventId: event1[0].id,
      title: "Opening Keynote: The Future of AI",
      speaker: "Dr. Sarah Chen",
      startTime: "09:00",
      duration: 60,
      capacity: 500,
      track: "Main Stage",
      description: "Exploring the transformative power of artificial intelligence",
    },
    {
      eventId: event1[0].id,
      title: "Workshop: Building Scalable Systems",
      speaker: "Michael Rodriguez",
      startTime: "11:00",
      duration: 90,
      capacity: 50,
      track: "Technical",
      description: "Hands-on workshop for building cloud-native applications",
    },
  ]);

  console.log(`Created ${2} sessions for event 1`);

  // Create sample analytics data
  const analyticsData = [];
  const startDate = new Date("2025-01-01");
  for (let i = 0; i < 6; i++) {
    const date = new Date(startDate);
    date.setMonth(date.getMonth() + i);
    analyticsData.push({
      eventId: event1[0].id,
      date,
      metric: "attendance",
      value: String(1200 + i * 600),
    });
  }

  await db.insert(analytics).values(analyticsData);

  console.log(`Created ${analyticsData.length} analytics records`);
  console.log("Database seeded successfully!");
}

seed().catch(console.error);
