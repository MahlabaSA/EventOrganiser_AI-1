import { 
  type User, 
  type InsertUser,
  type Event,
  type InsertEvent,
  type Attendee,
  type InsertAttendee,
  type Sponsor,
  type InsertSponsor,
  type Session,
  type InsertSession,
  type Analytics,
  type InsertAnalytics
} from "@shared/schema";
import { db } from "./db";
import { users, events, attendees, sponsors, sessions, analytics } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Events
  getEvents(): Promise<Event[]>;
  getEvent(id: string): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: string, event: Partial<InsertEvent>): Promise<Event | undefined>;
  deleteEvent(id: string): Promise<void>;
  
  // Attendees
  getAttendees(eventId: string): Promise<Attendee[]>;
  getAttendee(id: string): Promise<Attendee | undefined>;
  createAttendee(attendee: InsertAttendee): Promise<Attendee>;
  updateAttendee(id: string, attendee: Partial<InsertAttendee>): Promise<Attendee | undefined>;
  checkInAttendee(id: string): Promise<Attendee | undefined>;
  
  // Sponsors
  getSponsors(eventId: string): Promise<Sponsor[]>;
  getSponsor(id: string): Promise<Sponsor | undefined>;
  createSponsor(sponsor: InsertSponsor): Promise<Sponsor>;
  updateSponsor(id: string, sponsor: Partial<InsertSponsor>): Promise<Sponsor | undefined>;
  
  // Sessions
  getSessions(eventId: string): Promise<Session[]>;
  getSession(id: string): Promise<Session | undefined>;
  createSession(session: InsertSession): Promise<Session>;
  updateSession(id: string, session: Partial<InsertSession>): Promise<Session | undefined>;
  deleteSession(id: string): Promise<void>;
  
  // Analytics
  getAnalytics(eventId: string): Promise<Analytics[]>;
  createAnalytics(data: InsertAnalytics): Promise<Analytics>;
}

export class DbStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  // Events
  async getEvents(): Promise<Event[]> {
    return db.select().from(events).orderBy(desc(events.startDate));
  }

  async getEvent(id: string): Promise<Event | undefined> {
    const result = await db.select().from(events).where(eq(events.id, id)).limit(1);
    return result[0];
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const result = await db.insert(events).values(event).returning();
    return result[0];
  }

  async updateEvent(id: string, event: Partial<InsertEvent>): Promise<Event | undefined> {
    if (Object.keys(event).length === 0) {
      return this.getEvent(id);
    }
    const result = await db.update(events)
      .set({ ...event, updatedAt: new Date() })
      .where(eq(events.id, id))
      .returning();
    return result[0];
  }

  async deleteEvent(id: string): Promise<void> {
    await db.delete(events).where(eq(events.id, id));
  }

  // Attendees
  async getAttendees(eventId: string): Promise<Attendee[]> {
    return db.select().from(attendees).where(eq(attendees.eventId, eventId)).orderBy(desc(attendees.registeredAt));
  }

  async getAttendee(id: string): Promise<Attendee | undefined> {
    const result = await db.select().from(attendees).where(eq(attendees.id, id)).limit(1);
    return result[0];
  }

  async createAttendee(attendee: InsertAttendee): Promise<Attendee> {
    const result = await db.insert(attendees).values(attendee).returning();
    return result[0];
  }

  async updateAttendee(id: string, attendee: Partial<InsertAttendee>): Promise<Attendee | undefined> {
    if (Object.keys(attendee).length === 0) {
      return this.getAttendee(id);
    }
    const result = await db.update(attendees)
      .set(attendee)
      .where(eq(attendees.id, id))
      .returning();
    return result[0];
  }

  async checkInAttendee(id: string): Promise<Attendee | undefined> {
    const result = await db.update(attendees)
      .set({ status: "checked-in", checkedInAt: new Date() })
      .where(eq(attendees.id, id))
      .returning();
    return result[0];
  }

  // Sponsors
  async getSponsors(eventId: string): Promise<Sponsor[]> {
    return db.select().from(sponsors).where(eq(sponsors.eventId, eventId)).orderBy(desc(sponsors.createdAt));
  }

  async getSponsor(id: string): Promise<Sponsor | undefined> {
    const result = await db.select().from(sponsors).where(eq(sponsors.id, id)).limit(1);
    return result[0];
  }

  async createSponsor(sponsor: InsertSponsor): Promise<Sponsor> {
    const result = await db.insert(sponsors).values(sponsor).returning();
    return result[0];
  }

  async updateSponsor(id: string, sponsor: Partial<InsertSponsor>): Promise<Sponsor | undefined> {
    if (Object.keys(sponsor).length === 0) {
      return this.getSponsor(id);
    }
    const result = await db.update(sponsors)
      .set(sponsor)
      .where(eq(sponsors.id, id))
      .returning();
    return result[0];
  }

  // Sessions
  async getSessions(eventId: string): Promise<Session[]> {
    return db.select().from(sessions).where(eq(sessions.eventId, eventId)).orderBy(sessions.startTime);
  }

  async getSession(id: string): Promise<Session | undefined> {
    const result = await db.select().from(sessions).where(eq(sessions.id, id)).limit(1);
    return result[0];
  }

  async createSession(session: InsertSession): Promise<Session> {
    const result = await db.insert(sessions).values(session).returning();
    return result[0];
  }

  async updateSession(id: string, session: Partial<InsertSession>): Promise<Session | undefined> {
    if (Object.keys(session).length === 0) {
      return this.getSession(id);
    }
    const result = await db.update(sessions)
      .set(session)
      .where(eq(sessions.id, id))
      .returning();
    return result[0];
  }

  async deleteSession(id: string): Promise<void> {
    await db.delete(sessions).where(eq(sessions.id, id));
  }

  // Analytics
  async getAnalytics(eventId: string): Promise<Analytics[]> {
    return db.select().from(analytics).where(eq(analytics.eventId, eventId)).orderBy(analytics.date);
  }

  async createAnalytics(data: InsertAnalytics): Promise<Analytics> {
    const result = await db.insert(analytics).values(data).returning();
    return result[0];
  }
}

export const storage = new DbStorage();
