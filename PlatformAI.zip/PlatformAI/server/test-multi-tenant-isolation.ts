import { db } from "./db";
import { organizations, users, projects, tasks, risks, events } from "@shared/schema";
import { eq } from "drizzle-orm";

async function testMultiTenantIsolation() {
  console.log("🧪 Testing Multi-Tenant Isolation...\n");

  let testsPassed = 0;
  let testsFailed = 0;

  try {
    // Setup: Create two organizations with unique domains
    console.log("📋 Setup: Creating test organizations...");
    const timestamp = Date.now();
    const [org1] = await db.insert(organizations).values({
      name: "Test Org 1",
      domain: `test1-${timestamp}.com`,
      tier: "enterprise",
      active: true,
    }).returning();

    const [org2] = await db.insert(organizations).values({
      name: "Test Org 2",
      domain: `test2-${timestamp}.com`,
      tier: "free",
      active: true,
    }).returning();

    console.log(`✓ Created Org 1: ${org1.id}`);
    console.log(`✓ Created Org 2: ${org2.id}\n`);

    // Create users in each organization
    const [user1] = await db.insert(users).values({
      organizationId: org1.id,
      email: `user1-${timestamp}@test1.com`,
      firstName: "Test",
      lastName: "User1",
      passwordHash: "test",
      role: "admin",
    }).returning();

    const [user2] = await db.insert(users).values({
      organizationId: org2.id,
      email: `user2-${timestamp}@test2.com`,
      firstName: "Test",
      lastName: "User2",
      passwordHash: "test",
      role: "admin",
    }).returning();

    console.log(`✓ Created User 1 in Org 1: ${user1.id}`);
    console.log(`✓ Created User 2 in Org 2: ${user2.id}\n`);

    // TEST 1: Try to assign project manager from different organization
    console.log("🧪 TEST 1: Cross-organization project manager assignment");
    try {
      await db.insert(projects).values({
        organizationId: org1.id,
        name: "Test Project",
        status: "planning",
        budget: 10000,
        startDate: new Date("2025-06-01"),
        endDate: new Date("2025-12-31"),
        projectManager: user2.id, // User from Org 2 assigned to Org 1 project
      });
      console.log("❌ FAILED: Should have blocked cross-tenant assignment\n");
      testsFailed++;
    } catch (error) {
      if (error instanceof Error && error.message.includes("different organization")) {
        console.log("✅ PASSED: Correctly blocked cross-tenant project manager\n");
        testsPassed++;
      } else {
        console.log("❌ FAILED: Wrong error:", error);
        testsFailed++;
      }
    }

    // Create valid project in Org 1 for further tests
    const [project1] = await db.insert(projects).values({
      organizationId: org1.id,
      name: "Valid Project",
      status: "planning",
      budget: 10000,
      startDate: new Date("2025-06-01"),
      endDate: new Date("2025-06-30"),
      projectManager: user1.id,
    }).returning();

    // TEST 2: Try to assign task to user from different organization
    console.log("🧪 TEST 2: Cross-organization task assignment");
    try {
      await db.insert(tasks).values({
        organizationId: org1.id,
        projectId: project1.id,
        title: "Test Task",
        status: "todo",
        priority: "medium",
        assignedTo: user2.id, // User from Org 2
      });
      console.log("❌ FAILED: Should have blocked cross-tenant task assignment\n");
      testsFailed++;
    } catch (error) {
      if (error instanceof Error && error.message.includes("different organization")) {
        console.log("✅ PASSED: Correctly blocked cross-tenant task assignment\n");
        testsPassed++;
      } else {
        console.log("❌ FAILED: Wrong error:", error);
        testsFailed++;
      }
    }

    // TEST 3: Try to assign risk owner from different organization
    console.log("🧪 TEST 3: Cross-organization risk owner assignment");
    try {
      await db.insert(risks).values({
        organizationId: org1.id,
        projectId: project1.id,
        category: "financial",
        title: "Test Risk",
        description: "Test",
        likelihood: "possible",
        impact: "moderate",
        riskScore: 10,
        owner: user2.id, // User from Org 2
        status: "open",
      });
      console.log("❌ FAILED: Should have blocked cross-tenant risk owner\n");
      testsFailed++;
    } catch (error) {
      if (error instanceof Error && error.message.includes("different organization")) {
        console.log("✅ PASSED: Correctly blocked cross-tenant risk owner\n");
        testsPassed++;
      } else {
        console.log("❌ FAILED: Wrong error:", error);
        testsFailed++;
      }
    }

    // TEST 4: Try to create event with mismatched organizationId
    console.log("🧪 TEST 4: Event organizationId must match project organizationId");
    try {
      await db.insert(events).values({
        organizationId: org2.id, // Different org!
        projectId: project1.id, // Project in Org 1
        title: "Test Event",
        description: "Test Description",
        status: "planning",
        startDate: new Date("2025-06-01"),
        endDate: new Date("2025-06-03"),
        venue: "Test Venue",
        budget: 10000,
      });
      console.log("❌ FAILED: Should have blocked organizationId mismatch\n");
      testsFailed++;
    } catch (error) {
      if (error instanceof Error && error.message.includes("must match")) {
        console.log("✅ PASSED: Correctly enforced parent-child organization match\n");
        testsPassed++;
      } else {
        console.log("❌ FAILED: Wrong error:", error);
        testsFailed++;
      }
    }

    // TEST 5: Verify valid same-organization operations work
    console.log("🧪 TEST 5: Valid same-organization operations should succeed");
    try {
      await db.insert(tasks).values({
        organizationId: org1.id,
        projectId: project1.id,
        title: "Valid Task",
        status: "todo",
        priority: "medium",
        assignedTo: user1.id, // Same organization
      });
      console.log("✅ PASSED: Valid same-organization task created successfully\n");
      testsPassed++;
    } catch (error) {
      console.log("❌ FAILED: Valid operation was blocked:", error);
      testsFailed++;
    }

    // Cleanup
    console.log("🧹 Cleaning up test data...");
    await db.delete(organizations).where(eq(organizations.id, org1.id));
    await db.delete(organizations).where(eq(organizations.id, org2.id));
    console.log("✓ Test data cleaned up\n");

  } catch (error) {
    console.error("❌ Test suite failed with error:", error);
    testsFailed++;
  }

  // Summary
  console.log("═".repeat(60));
  console.log("📊 TEST RESULTS");
  console.log("═".repeat(60));
  console.log(`✅ Passed: ${testsPassed}`);
  console.log(`❌ Failed: ${testsFailed}`);
  console.log("═".repeat(60));

  if (testsFailed > 0) {
    console.log("\n⚠️  CRITICAL: Multi-tenant isolation is NOT working correctly!");
    process.exit(1);
  } else {
    console.log("\n✅ SUCCESS: All multi-tenant isolation tests passed!");
    process.exit(0);
  }
}

testMultiTenantIsolation();
