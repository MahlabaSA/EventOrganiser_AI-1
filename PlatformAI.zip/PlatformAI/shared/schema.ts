import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, numeric, pgEnum, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Multi-tenant Organizations (The Client/Tenant)
export const organizations = pgTable("organizations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  domain: text("domain").unique(),
  tier: text("tier").notNull().default("standard"),
  settings: jsonb("settings"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Users with multi-tenant support
export const userRoleEnum = pgEnum("user_role", ["admin", "project_manager", "event_manager", "coordinator", "viewer"]);

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash"),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  role: userRoleEnum("role").notNull().default("event_manager"),
  company: text("company"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// PMBOK-aligned Projects
export const projectStatusEnum = pgEnum("project_status", ["initiated", "planning", "executing", "monitoring", "closing", "closed"]);

export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description"),
  status: projectStatusEnum("status").notNull().default("initiated"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  budget: numeric("budget", { precision: 12, scale: 2 }).notNull(),
  projectManager: varchar("project_manager").references(() => users.id),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Events (linked to Projects and Organizations)
export const eventStatusEnum = pgEnum("event_status", ["planning", "active", "completed", "cancelled"]);

export const events = pgTable("events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  projectId: varchar("project_id").references(() => projects.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  description: text("description"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  venue: text("venue").notNull(),
  budget: numeric("budget", { precision: 12, scale: 2 }).notNull(),
  status: eventStatusEnum("status").notNull().default("planning"),
  imageUrl: text("image_url"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Tasks (linked to Projects)
export const taskStatusEnum = pgEnum("task_status", ["todo", "in_progress", "blocked", "completed", "cancelled"]);
export const taskPriorityEnum = pgEnum("task_priority", ["low", "medium", "high", "critical"]);

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  status: taskStatusEnum("status").notNull().default("todo"),
  priority: taskPriorityEnum("priority").notNull().default("medium"),
  assignedTo: varchar("assigned_to").references(() => users.id),
  dueDate: timestamp("due_date"),
  completedAt: timestamp("completed_at"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ISO 31000 Risk Register
export const riskLikelihoodEnum = pgEnum("risk_likelihood", ["rare", "unlikely", "possible", "likely", "almost_certain"]);
export const riskImpactEnum = pgEnum("risk_impact", ["negligible", "minor", "moderate", "major", "catastrophic"]);
export const riskCategoryEnum = pgEnum("risk_category", ["financial", "operational", "strategic", "compliance", "hse", "cybersecurity", "reputational"]);

export const risks = pgTable("risks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  category: riskCategoryEnum("category").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  likelihood: riskLikelihoodEnum("likelihood").notNull(),
  impact: riskImpactEnum("impact").notNull(),
  riskScore: integer("risk_score").notNull(),
  mitigationPlan: text("mitigation_plan"),
  owner: varchar("owner").references(() => users.id),
  status: text("status").notNull().default("open"),
  aiGenerated: boolean("ai_generated").notNull().default(false),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Speakers (separate entity for content curation)
export const speakers = pgTable("speakers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  email: text("email").notNull(),
  bio: text("bio"),
  title: text("title"),
  company: text("company"),
  expertise: text("expertise").array(),
  photoUrl: text("photo_url"),
  linkedinUrl: text("linkedin_url"),
  twitterHandle: text("twitter_handle"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Delegates (Participants/Attendees)
export const attendeeStatusEnum = pgEnum("attendee_status", ["registered", "checked-in", "no-show", "cancelled"]);
export const attendeePaymentStatusEnum = pgEnum("attendee_payment_status", ["pending", "paid", "refunded", "failed"]);

export const attendees = pgTable("attendees", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  eventId: varchar("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  email: text("email").notNull(),
  company: text("company"),
  ticketType: text("ticket_type").notNull(),
  ticketPrice: numeric("ticket_price", { precision: 10, scale: 2 }),
  paymentStatus: attendeePaymentStatusEnum("payment_status").notNull().default("pending"),
  stripeSessionId: text("stripe_session_id"),
  status: attendeeStatusEnum("status").notNull().default("registered"),
  dietaryRequirements: text("dietary_requirements"),
  accessibilityNeeds: text("accessibility_needs"),
  registeredAt: timestamp("registered_at").notNull().defaultNow(),
  checkedInAt: timestamp("checked_in_at"),
});

export const sponsorTierEnum = pgEnum("sponsor_tier", ["platinum", "gold", "silver", "bronze"]);

export const sponsors = pgTable("sponsors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  eventId: varchar("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  tier: sponsorTierEnum("tier").notNull(),
  package: text("package").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  roi: integer("roi"),
  leads: integer("leads"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  eventId: varchar("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  speakerId: varchar("speaker_id").references(() => speakers.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  speaker: text("speaker").notNull(),
  startTime: text("start_time").notNull(),
  duration: integer("duration").notNull(),
  capacity: integer("capacity").notNull(),
  track: text("track"),
  description: text("description"),
  aiGenerated: boolean("ai_generated").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Venue Layouts (Fabric.js canvas data for 2D venue design)
export const venueLayouts = pgTable("venue_layouts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  eventId: varchar("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  canvasData: jsonb("canvas_data").notNull(),
  thumbnail: text("thumbnail"),
  version: integer("version").notNull().default(1),
  isActive: boolean("is_active").notNull().default(true),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const analytics = pgTable("analytics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  eventId: varchar("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  date: timestamp("date").notNull(),
  metric: text("metric").notNull(),
  value: numeric("value", { precision: 12, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas
export const insertOrganizationSchema = createInsertSchema(organizations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  completedAt: true,
});

export const insertRiskSchema = createInsertSchema(risks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSpeakerSchema = createInsertSchema(speakers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAttendeeSchema = createInsertSchema(attendees).omit({
  id: true,
  registeredAt: true,
  checkedInAt: true,
});

export const insertSponsorSchema = createInsertSchema(sponsors).omit({
  id: true,
  createdAt: true,
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  createdAt: true,
});

export const insertVenueLayoutSchema = createInsertSchema(venueLayouts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAnalyticsSchema = createInsertSchema(analytics).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertOrganization = z.infer<typeof insertOrganizationSchema>;
export type Organization = typeof organizations.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export type InsertRisk = z.infer<typeof insertRiskSchema>;
export type Risk = typeof risks.$inferSelect;

export type InsertSpeaker = z.infer<typeof insertSpeakerSchema>;
export type Speaker = typeof speakers.$inferSelect;

export type InsertAttendee = z.infer<typeof insertAttendeeSchema>;
export type Attendee = typeof attendees.$inferSelect;

export type InsertSponsor = z.infer<typeof insertSponsorSchema>;
export type Sponsor = typeof sponsors.$inferSelect;

export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

export type InsertVenueLayout = z.infer<typeof insertVenueLayoutSchema>;
export type VenueLayout = typeof venueLayouts.$inferSelect;

export type InsertAnalytics = z.infer<typeof insertAnalyticsSchema>;
export type Analytics = typeof analytics.$inferSelect;
